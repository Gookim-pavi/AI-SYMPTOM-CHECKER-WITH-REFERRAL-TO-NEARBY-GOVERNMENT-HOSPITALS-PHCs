# 🩺 SSS Medical Assist: Smart Symptom Checker & Government Hospital / PHC Referral Network

An advanced, AI-driven public healthcare triage and smart referral routing system built on **Java 25 LTS** with an ultra-responsive, glassmorphic cyber-medical web interface. 

---

## 🌟 Key Highlights & Innovations

1. **Pure Java 25 Embedded Engine**
   - Built on standard Java (`com.sun.net.httpserver`, `java.util.concurrent`, `java.nio`, `java.security`) with **zero external runtime dependencies**.
   - High-throughput multi-threaded REST API server and static web asset delivery.

2. **Bayesian Probabilistic Clinical Triage & Red-Flag Detection**
   - Pure Java Bayesian inference engine that computes posterior disease probabilities given patient symptom vectors.
   - Acute Red-Flag detection (e.g. Myocardial Infarction, Ischemic Stroke FAST, Sepsis, Meningitis, Obstetric Emergencies).
   - NEWS2 (National Early Warning Score) & qSOFA physiological vital sign risk calculation (SpO2, Systolic BP, Temperature, Pulse).

3. **Multi-Modal AI Symptom Input**
   - **Interactive 3D/SVG Human Body Anatomical Navigator**: Clickable body regions (Head, ENT, Chest, Respiratory, Abdomen, Pelvis, Limbs, Skin, Systemic) with instant symptom filtering.
   - **Natural Language AI NLP Parser**: Transcribes and extracts medical symptom entities, durations, and negations ("no fever", "denies chest pain") from free-form clinical descriptions.
   - **Voice Input (STT) & Speech Synthesis (TTS)**: Hands-free voice symptom input and audible AI recommendations.
   - **Visual Symptom Tag Cloud**: Searchable ontology with severity sliders (1-10) and duration tags.

4. **Geo-Intelligent Government Health Referral Network**
   - Real-time Haversine distance and transit-time calculator matching patients to nearby **Sub-Centres (Ayushman Arogya Mandir)**, **Primary Health Centres (PHCs)**, **Community Health Centres (CHCs/FRUs)**, **District Hospitals**, and **Apex Medical Colleges / AIIMS**.
   - Interactive GIS OpenStreetMap / Leaflet interface with custom color-coded facility pins, 24x7 emergency filters, and live bed occupancy estimates.

5. **Official Government Health Referral Pass (Digital Health Voucher)**
   - Issues authentic National Health Mission / Government of India styled referral certificates.
   - Unique Referral ID, ABHA Health ID format, Priority Queue Tokens (`RED-STAT`, `AMBER-URGENT`, `GREEN-REGULAR`).
   - Cryptographic SHA-256 digital verification seal and dynamic QR Code generation for one-page printing.

6. **Doctor & Health Worker Tele-Triage Desk**
   - Real-time patient triage feed for PHC Medical Officers and ASHA/ANM workers.
   - OPD Token & QR verification tool with instant validity checks.
   - Regional bed occupancy tracker.

7. **Fullscreen Emergency SOS Strobe Mode**
   - High-visibility emergency beacon with one-tap 108/112 ambulance dialer, live GPS coordinate readout, and step-by-step audio-visual CPR and First Aid guides.

---

## 📁 Project Architecture

```
c:\GAMES\JAVA\
├── bin/                             # Compiled Java .class binaries
├── src/com/sanjeevani/
│   ├── App.java                     # Main application entry point & bootstrap
│   ├── models/
│   │   ├── Symptom.java             # SNOMED/ICD symptom data model
│   │   ├── DiseaseProfile.java      # Disease likelihood matrix & triage protocols
│   │   ├── PatientProfile.java      # Demographics, comorbidities & vital signs
│   │   ├── HealthFacility.java      # Government hospital / PHC metadata model
│   │   ├── TriageResult.java        # Urgency level, differentials & advice
│   │   └── ReferralSlip.java        # Digital official referral voucher model
│   ├── engine/
│   │   ├── SymptomKnowledgeBase.java# Clinical ontology & ICD-11 knowledge graph
│   │   ├── BayesianTriageEngine.java# Multi-factor Bayesian triage calculator
│   │   ├── NLPTextExtractor.java    # Rule-based natural language clinical parser
│   │   ├── FacilityLocatorService.java # Geo-spatial proximity & tier routing
│   │   └── ReferralSlipGenerator.java# Token issuer & cryptographic verifier
│   ├── data/
│   │   └── HospitalDatabase.java    # Curated Indian Government Health Facilities
│   └── server/
│       └── HttpServerEngine.java    # High-concurrency Java HTTP server & REST API
├── web/
│   ├── index.html                   # Glassmorphic UI with Anatomical Body Map
│   ├── css/styles.css               # Cyber-medical dark/light theme & print layout
│   └── js/app.js                    # Client state, GIS Leaflet map, TTS, QR renderer
├── build.bat                        # One-click Java compiler script
├── run.bat                          # One-click application launcher
├── README.md                        # Project documentation
└── PROJECT_GUIDE.md                 # Academic presentation & viva guide
```

---

## 🚀 Quick Start Guide

### Prerequisites
- Java Development Kit (JDK 21 or Java 25 LTS recommended).
- Modern web browser (Chrome, Edge, Firefox, Brave).

### Step 1: Compile the Project
Double click `build.bat` or run in PowerShell:
```powershell
.\build.bat
```

### Step 2: Launch the Sanjeevani AI Server
Double click `run.bat` or run in PowerShell:
```powershell
.\run.bat
```

### Step 3: Open in Browser
Visit the live portal in your browser:
👉 **`http://localhost:8080`**

---

## 📡 REST API Documentation

| Endpoint | Method | Description |
|---|---|---|
| `/api/health` | `GET` | Server status, uptime, and database telemetry |
| `/api/symptoms` | `GET` | Full catalog of clinical symptoms and ICD mappings |
| `/api/nlp-parse` | `POST` | Free-text NLP entity extraction and duration parser |
| `/api/triage` | `POST` | Full Bayesian clinical triage calculation |
| `/api/referrals/find-facilities` | `POST` | Geo-spatial proximity query for nearby PHCs/Hospitals |
| `/api/referrals/generate-slip` | `POST` | Generates official Government Referral Pass |
| `/api/referrals/slips` | `GET` | Retrieves all issued active referral passes |
| `/api/dashboard/stats` | `GET` | Doctor portal statistics and bed network metrics |

---

## 📜 Clinical Disclaimer
*Sanjeevani AI is intended as a preliminary healthcare screening and public referral assistance tool. It does not replace definitive medical diagnosis by a certified medical practitioner. In emergency conditions, dial **108** immediately.*
